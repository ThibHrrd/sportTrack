<!DOCTYPE html>

<html>

    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="ressources/css/style.css"/>
        <title>ERROR</title>
    </head>

    <body>
        <p id="Error">
            ERROR 404S
        </p>
    </body>

</html>