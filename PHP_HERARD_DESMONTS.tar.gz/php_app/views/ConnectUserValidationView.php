<?php
    echo("Hello world !");
?>